//
//  NewGameViewController.h
//  CIU196Group1
//
//  Copyright (c) 2013 Eric Zhang, Robert Sebescen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewGameViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>


@end
